from turtle import left, right

import pygame
import math
import random
from collections import deque

pygame.init()

WIDTH, HEIGHT = 1000, 1000
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

BLACK = (0, 0, 0)
BROWN = (139, 69, 19)
WHITE = (255, 255, 255)
GRAY = (60, 60, 60)

WALL_THICKNESS = 60

def get_rect(x, y):
    return pygame.Rect(x - 20, y - 20, 40, 40)

BASE_WALLS = [
    pygame.Rect(0, 0, WIDTH, WALL_THICKNESS),
    pygame.Rect(0, HEIGHT - WALL_THICKNESS, WIDTH, WALL_THICKNESS),
    pygame.Rect(0, 0, WALL_THICKNESS, HEIGHT),
    pygame.Rect(WIDTH - WALL_THICKNESS, 0, WALL_THICKNESS, HEIGHT),
]
WALLS = BASE_WALLS.copy()
GLOBAL_LEFT_TRAILS = []
GLOBAL_RIGHT_TRAILS = []

# ---------------- HELPERS ----------------
def lerp_angle(a, b, t):
    diff = (b - a + 180) % 360 - 180
    return a + diff * t

def angle_to_target(x1, y1, x2, y2):
    return math.degrees(math.atan2(y2 - y1, x2 - x1))

def vec_from_angle(angle):
    rad = math.radians(angle)
    return math.cos(rad), math.sin(rad)

def get_tread_positions(x, y, angle, offset=18):
    # perpendicular direction to heading
    perp_angle = angle + 90
    dx, dy = vec_from_angle(perp_angle)

    left_x = x + dx * offset
    left_y = y + dy * offset
    right_x = x - dx * offset
    right_y = y - dy * offset

    return (left_x, left_y), (right_x, right_y)

def avoid_walls(x, y, angle):
    look_distance = 60

    dx, dy = vec_from_angle(angle)

    ahead_rect = pygame.Rect(
        x + dx * look_distance - 10,
        y + dy * look_distance - 10,
        20, 20
    )

    hit = False

    for w in WALLS:
        if ahead_rect.colliderect(w):
            hit = True
            break

    return hit

# ---------------- BULLET ----------------
class Bullet:
    def __init__(self, x, y, angle, owner, bounce=True, max_bounces=1):
        self.x = x
        self.y = y
        self.angle = angle
        self.speed = 5
        self.owner = owner
        self.alive = True
        self.bounce = bounce
        self.bounces = 0
        self.max_bounces = max_bounces if bounce else 0
        self.spawn_timer = 5
        self.radius = 4
        self.wall_piercing = False

    def update(self):
        dx, dy = vec_from_angle(self.angle)
        self.x += dx * self.speed
        self.y += dy * self.speed

        bullet_rect = pygame.Rect(self.x - 2, self.y - 2, 4, 4)

        if self.spawn_timer > 0:
            self.spawn_timer -= 1

        if self.spawn_timer <= 0:
            for wall in WALLS:
                if self.wall_piercing:
                    return
                if bullet_rect.colliderect(wall):

                    if not self.bounce:
                        self.alive = False
                        return

                    self.bounces += 1
                    if self.bounces > self.max_bounces:
                        self.alive = False
                        return

                    # --- compute overlap ---
                    overlap_left = abs(bullet_rect.right - wall.left)
                    overlap_right = abs(bullet_rect.left - wall.right)
                    overlap_top = abs(bullet_rect.bottom - wall.top)
                    overlap_bottom = abs(bullet_rect.top - wall.bottom)

                    min_overlap = min(overlap_left, overlap_right, overlap_top, overlap_bottom)

                    # --- reflect ---
                    if min_overlap in (overlap_left, overlap_right):
                        self.angle = 180 - self.angle
                        if overlap_left < overlap_right:
                            self.x -= 2
                        else:
                            self.x += 2
                    else:
                        self.angle = -self.angle
                        if overlap_top < overlap_bottom:
                            self.y -= 2
                        else:
                            self.y += 2

                    self.angle %= 360

                # IMPORTANT: rebuild rect after correction
                bullet_rect = pygame.Rect(self.x - 2, self.y - 2, 4, 4)

                # IMPORTANT: don't return here
                # let it resolve multiple collisions in same frame

    def draw(self, surf):
        if self.owner == "player":
            color = (80, 160, 255)   # blue
        else:
            color = WHITE

        pygame.draw.circle(
            surf,
            color,
            (int(self.x), int(self.y)),
            self.radius
        )

# ---------------- PLAYER ----------------
class Tank:
    def __init__(self):
        self.x = 120
        self.y = HEIGHT - 120
        self.angle = 0
        self.turret_angle = 0
        self.speed = 3
        self.rot_speed = 3
        self.turret_turn_speed = 0.08
        self.left_trail = deque()
        self.right_trail = deque()
        self.alive = True
        self.size = 40

    def update(self, keys, mouse_pos):
        mx, my = mouse_pos

        forward_x, forward_y = vec_from_angle(self.angle)

        move_x = 0
        move_y = 0

        if keys[pygame.K_a]:
            self.angle -= self.rot_speed
        if keys[pygame.K_d]:
            self.angle += self.rot_speed

        if keys[pygame.K_w]:
            move_x += forward_x * self.speed
            move_y += forward_y * self.speed
        if keys[pygame.K_s]:
            move_x -= forward_x * self.speed
            move_y -= forward_y * self.speed

        # -------- X AXIS COLLISION --------
        self.x += move_x
        rect = pygame.Rect(self.x - self.size/2, self.y - self.size/2, self.size, self.size)
        for w in WALLS:
            if rect.colliderect(w):
                self.x -= move_x
                break

        # -------- Y AXIS COLLISION --------
        self.y += move_y
        rect = pygame.Rect(self.x - self.size/2, self.y - self.size/2, self.size, self.size)
        for w in WALLS:
            if rect.colliderect(w):
                self.y -= move_y
                break

        self.turret_angle = angle_to_target(self.x, self.y, mx, my)

        left, right = get_tread_positions(self.x, self.y, self.angle)

        GLOBAL_LEFT_TRAILS.append(left)
        GLOBAL_RIGHT_TRAILS.append(right)

    def draw(self, surf):

        body = pygame.Surface((60, 40), pygame.SRCALPHA)
        body.fill((80, 80, 80))
        pygame.draw.rect(body, (40, 120, 255), (42, 10, 18, 20))
        pygame.draw.rect(body, BLACK, (0, 0, 60, 10))
        pygame.draw.rect(body, BLACK, (0, 30, 60, 10))

        rotated = pygame.transform.rotate(body, -self.angle)
        rect = rotated.get_rect(center=(self.x, self.y))
        surf.blit(rotated, rect.topleft)

        # =========================
        # PLAYER BARREL (ADDED)
        # =========================
        dx, dy = vec_from_angle(self.turret_angle)
        end_x = self.x + dx * 35
        end_y = self.y + dy * 35
        pygame.draw.line(surf, (30, 30, 30), (self.x, self.y), (end_x, end_y), 6)

# ---------------- ENEMY AI (UNCHANGED) ----------------
class EnemyTank:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.alive = True
        self.angle = 180
        self.turret_angle = 180
        self.speed = 2.0
        self.rot_speed = 2
        self.turn_speed = 0.2
        self.shoot_timer = 0
        self.turning = False
        self.turn_target = 0
        self.avoid_direction = 0
        self.left_trail = deque()
        self.right_trail = deque()
        self.color = (50, 140, 50)
        self.size = 40

    def update(self, player, enemy_bullets, enemies):

        target_angle = angle_to_target(self.x, self.y, player.x, player.y)

        self.turret_angle = lerp_angle(self.turret_angle, target_angle, self.turn_speed)

        front_dx, front_dy = vec_from_angle(self.angle)
        left_dx, left_dy = vec_from_angle(self.angle - 35)
        right_dx, right_dy = vec_from_angle(self.angle + 35)

        sensor_distance = 70

        front_sensor = pygame.Rect(self.x + front_dx * sensor_distance - 5,
                                   self.y + front_dy * sensor_distance - 5, 10, 10)

        left_sensor = pygame.Rect(self.x + left_dx * sensor_distance - 5,
                                  self.y + left_dy * sensor_distance - 5, 10, 10)

        right_sensor = pygame.Rect(self.x + right_dx * sensor_distance - 5,
                                   self.y + right_dy * sensor_distance - 5, 10, 10)

        wall_front = wall_left = wall_right = False

        for w in WALLS:
            if front_sensor.colliderect(w): wall_front = True
            if left_sensor.colliderect(w): wall_left = True
            if right_sensor.colliderect(w): wall_right = True

        desired_angle = target_angle

        avoid_x = 0
        avoid_y = 0

        for e in enemies:
            if e is self:
                continue

            dx = self.x - e.x
            dy = self.y - e.y
            dist = math.hypot(dx, dy)

            if dist < 120 and dist > 0:
                force = (120 - dist) / 120
                avoid_x += (dx / dist) * force
                avoid_y += (dy / dist) * force

        if avoid_x or avoid_y:
            avoid_angle = math.degrees(math.atan2(avoid_y, avoid_x))
            desired_angle = lerp_angle(desired_angle, avoid_angle, 0.35)

        if wall_front and not self.turning:
            self.turning = True
            if wall_left and not wall_right:
                self.avoid_direction = 1
            elif wall_right and not wall_left:
                self.avoid_direction = -1
            else:
                self.avoid_direction = random.choice([-1, 1])

            self.turn_target = self.angle + self.avoid_direction * 90

        if self.turning:
            desired_angle = self.turn_target
            diff = (self.turn_target - self.angle + 180) % 360 - 180
            if abs(diff) < 10:
                self.turning = False

        diff = (desired_angle - self.angle + 180) % 360 - 180

        if diff > 5:
            self.angle += self.rot_speed
        elif diff < -5:
            self.angle -= self.rot_speed

        dx, dy = vec_from_angle(self.angle)

        # -------- X AXIS COLLISION --------
        self.x += dx * self.speed
        rect = pygame.Rect(self.x - self.size/2, self.y - self.size/2, self.size, self.size)
        for w in WALLS:
            if rect.colliderect(w):
                self.x -= dx * self.speed
                break

        # -------- Y AXIS COLLISION --------
        self.y += dy * self.speed
        rect = pygame.Rect(self.x - self.size/2, self.y - self.size/2, self.size, self.size)
        for w in WALLS:
            if rect.colliderect(w):
                self.y -= dy * self.speed
                break

        self.shoot_timer += 1
        if self.shoot_timer > 90:
            bx = self.x + math.cos(math.radians(self.turret_angle)) * 35
            by = self.y + math.sin(math.radians(self.turret_angle)) * 35

            enemy_bullets.append(
            Bullet(
                bx,
                by,
                self.turret_angle,
                "enemy",
                bounce=False,
            )
        )

            self.shoot_timer = 0
        left, right = get_tread_positions(self.x, self.y, self.angle)

        GLOBAL_LEFT_TRAILS.append(left)
        GLOBAL_RIGHT_TRAILS.append(right)

    def draw(self, surf):
        body = pygame.Surface((60, 40), pygame.SRCALPHA)
        body.fill(self.color)
        pygame.draw.rect(body, BLACK, (0, 0, 60, 10))
        pygame.draw.rect(body, BLACK, (0, 30, 60, 10))

        rotated = pygame.transform.rotate(body, -self.angle)
        rect = rotated.get_rect(center=(self.x, self.y))
        surf.blit(rotated, rect.topleft)

        # =========================
        # ENEMY BARREL (ADDED)
        # =========================
        dx, dy = vec_from_angle(self.turret_angle)
        end_x = self.x + dx * 35
        end_y = self.y + dy * 35
        pygame.draw.line(surf, (0, 80, 0), (self.x, self.y), (end_x, end_y), 6)

# ---------------- TRIPLE SHOT ----------------
class TripleShotTank(EnemyTank):
    def __init__(self, x, y):
        super().__init__(x, y)
        self.shoot_timer = 0
        self.color = (160, 60, 200)
    
    def update(self, player, enemy_bullets, enemies):
        super().update(player, enemy_bullets, enemies)
        

        self.shoot_timer += 1

        if self.shoot_timer > 90:

            base = self.turret_angle

            angles = [
                base,
                base - 15,
                base + 15
            ]

            for a in angles:
                bx = self.x + math.cos(math.radians(a)) * 35
                by = self.y + math.sin(math.radians(a)) * 35

                enemy_bullets.append(
                    Bullet(bx, by, a, "enemy", bounce=True, max_bounces=1)
                )

            self.shoot_timer = 0

# ---------------- RED ARMOR BURST TANK ----------------
class RedArmoredBurstTank(EnemyTank):
    def __init__(self, x, y):
        super().__init__(x, y)

        self.health = 2              
        self.color = (200, 40, 40)   
        self.shoot_timer = 0
        self.burst_delay = 15       
        self.burst_count = 0
        self.bursting = False
        self.speed = 0.8

    def take_hit(self):
        self.health -= 1
        if self.health <= 0:
            self.alive = False

    def update(self, player, enemy_bullets, enemies):
        super().update(player, enemy_bullets, enemies)

        # shooting logic
        self.shoot_timer += 1

        if not self.bursting and self.shoot_timer > 90:
            self.bursting = True
            self.burst_count = 0
            self.shoot_timer = 0

        # BURST FIRE (3 shots)
        if self.bursting:
            if self.shoot_timer % self.burst_delay == 0:

                angles = [
                    self.turret_angle,
                    self.turret_angle - 10,
                    self.turret_angle + 10
                ]

                for a in angles:
                    bx = self.x + math.cos(math.radians(a)) * 35
                    by = self.y + math.sin(math.radians(a)) * 35

                    enemy_bullets.append(
                        Bullet(
                            bx, by,
                            a,
                            "enemy",
                            bounce=True,
                            max_bounces=2   # 👈 requested
                        )
                    )

                self.burst_count += 1

                if self.burst_count >= 3:
                    self.bursting = False
                    self.shoot_timer = 0

    def draw(self, surf):
        body = pygame.Surface((60, 40), pygame.SRCALPHA)

        body.fill(self.color)

        pygame.draw.rect(body, BLACK, (0, 0, 60, 10))
        pygame.draw.rect(body, BLACK, (0, 30, 60, 10))

        rotated = pygame.transform.rotate(body, -self.angle)
        rect = rotated.get_rect(center=(self.x, self.y))
        surf.blit(rotated, rect.topleft)

        dx, dy = vec_from_angle(self.turret_angle)
        end_x = self.x + dx * 35
        end_y = self.y + dy * 35

        pygame.draw.line(surf, (120, 0, 0), (self.x, self.y), (end_x, end_y), 6)

# ---------------- Sniper Tank ----------------
class SniperTank(EnemyTank):
    def __init__(self, x, y):
        super().__init__(x, y)
        

        self.color = (255, 255, 255)   # dark = “sniper vibe”
        self.health = 1

        self.shoot_timer = 0
        self.shoot_delay = 120      # slow fire rate
        self.strafe_dir = random.choice([-1, 1])

    def take_hit(self):
        self.health -= 1
        if self.health <= 0:
            self.alive = False

    def update(self, player, enemy_bullets, enemies):
        # -------- distance control (stay far) --------
        dx = self.x - player.x
        dy = self.y - player.y
        dist = math.hypot(dx, dy)

        desired_angle = angle_to_target(self.x, self.y, player.x, player.y)

        # aim VERY accurately (less smoothing than others)
        self.turret_angle = lerp_angle(self.turret_angle, desired_angle, 0.05)

        # keep distance (simple AI)
        move_angle = None

        if dist < 300:
            # move away
            move_angle = math.degrees(math.atan2(dy, dx))

        elif dist > 450:
            # move closer
            move_angle = math.degrees(math.atan2(-dy, -dx))

        # rotate body toward movement direction
        if move_angle is not None:

            self.angle = lerp_angle(self.angle, move_angle, 0.08)

            dx_move, dy_move = vec_from_angle(self.angle)

            self.x += dx_move * self.speed
            self.y += dy_move * self.speed

        # -------- shooting --------
        self.shoot_timer += 1

        if self.shoot_timer > self.shoot_delay:
            bx = self.x + math.cos(math.radians(self.turret_angle)) * 35
            by = self.y + math.sin(math.radians(self.turret_angle)) * 35

            bullet = Bullet(bx, by, self.turret_angle, "enemy", bounce=False)
            bullet.speed = 10  # faster sniper shot
            enemy_bullets.append(bullet)
            
            self.shoot_timer = 0

        # trail (same as others)
        left, right = get_tread_positions(self.x, self.y, self.angle)
        self.left_trail.append(left)
        self.right_trail.append(right)

# ---------------- Tack shooter tank ----------------
class TackShooterTank(EnemyTank):
    def __init__(self, x, y):
        super().__init__(x, y)

        self.color = (200, 120, 40)
        self.health = 1

        self.shoot_timer = 0
        self.shoot_delay = 60
        self.spread_count = 10

    def take_hit(self):
        self.health -= 1
        if self.health <= 0:
            self.alive = False    

    def update(self, player, enemy_bullets, enemies):
        # DOES NOT MOVE

        target_angle = angle_to_target(self.x, self.y, player.x, player.y)
        self.turret_angle = lerp_angle(self.turret_angle, target_angle, 0.1)

        self.shoot_timer += 1

        # ---------------- TACK SHOOTER ATTACK ----------------
        if self.shoot_timer % 180 == 0:

            tack_count = 16

            for i in range(tack_count):

                angle = i * (360 / tack_count)

                bx = self.x + math.cos(math.radians(angle)) * 20
                by = self.y + math.sin(math.radians(angle)) * 20

                enemy_bullets.append(
                    Bullet(
                        bx,
                        by,
                        angle,
                        "enemy",
                        bounce=False
                    )
                )

        if self.shoot_timer > self.shoot_delay:

            for i in range(self.spread_count):
                angle = self.turret_angle + (i * (360 / self.spread_count))

                bx = self.x + math.cos(math.radians(angle)) * 10
                by = self.y + math.sin(math.radians(angle)) * 10

                enemy_bullets.append(
                    Bullet(bx, by, angle, "enemy", bounce=False)
                )

            self.shoot_timer = 0

        # optional: keep trail or remove it
        left, right = get_tread_positions(self.x, self.y, 0)
        self.left_trail.append(left)
        self.right_trail.append(right)

    def draw(self, surf):
        # SIMPLE CIRCLE ONLY (NO BARREL, NO BODY)

        pygame.draw.circle(
            surf,
            self.color,
            (int(self.x), int(self.y)),
            22
        )

        # optional: small inner core to show direction
        dx, dy = vec_from_angle(self.turret_angle)
        core_x = self.x + dx * 8
        core_y = self.y + dy * 8

        pygame.draw.circle(
            surf,
            (255, 200, 100),
            (int(core_x), int(core_y)),
            5
        )

class BossTank(EnemyTank):
    def __init__(self, x, y):
        super().__init__(x, y)

        self.health = 8
        self.color = (200, 40, 40)

        self.shoot_timer = 0
        self.shoot_delay = 70  # normal pacing
        self.speed = 1.0
        self.big_shot_timer = 0

        self.tack_timer = 0

        self.size = 80  

    def take_hit(self):
        self.health -= 1
        if self.health <= 0:
            self.alive = False

    def update(self, player, enemy_bullets, enemies):
        super().update(player, enemy_bullets, enemies)

        # shooting timer
        self.shoot_timer += 1
        self.big_shot_timer += 2
        self.tack_timer += 2

        # ---------------- BIG WALL-PIERCING SHOT ----------------
        if self.big_shot_timer > 240:

            bx = self.x + math.cos(math.radians(self.turret_angle)) * 60
            by = self.y + math.sin(math.radians(self.turret_angle)) * 60

            big_bullet = Bullet(
                bx,
                by,
                self.turret_angle,
                "enemy",
                bounce=False
            )

            # custom properties
            big_bullet.speed = 3
            big_bullet.radius = 14
            big_bullet.wall_piercing = True

            enemy_bullets.append(big_bullet)

            self.big_shot_timer = 0

        if self.shoot_timer > self.shoot_delay:
            base = self.turret_angle

            # 👇 5-shot spread (NOT burst over time, all at once)
            spread = [-30, -15, 0, 15, 30]

            for s in spread:
                a = base + s

                bx = self.x + math.cos(math.radians(a)) * 45
                by = self.y + math.sin(math.radians(a)) * 45

                enemy_bullets.append(
                    Bullet(bx, by, a, "enemy", bounce=True, max_bounces=1)
                )

            self.shoot_timer = 0
        
        # ---------------- TACK SHOOTER ATTACK ----------------
        if self.tack_timer > 180:

            tack_count = 16

            for i in range(tack_count):

                angle = i * (360 / tack_count)

                bx = self.x + math.cos(math.radians(angle)) * 20
                by = self.y + math.sin(math.radians(angle)) * 20

                enemy_bullets.append(
                    Bullet(
                        bx,
                        by,
                        angle,
                        "enemy",
                        bounce=False
                    )
                )
            self.tack_timer = 0
        
        # BIGGER TRACK SPACING FOR BOSS
        left, right = get_tread_positions(
            self.x,
            self.y,
            self.angle,
            offset=32
        )

        GLOBAL_LEFT_TRAILS.append(left)
        GLOBAL_RIGHT_TRAILS.append(right)

    def draw(self, surf):
        # BIG BODY (scaled up)
        body = pygame.Surface((100, 80), pygame.SRCALPHA)
        body.fill(self.color)

        pygame.draw.rect(body, BLACK, (0, 0, 100, 14))
        pygame.draw.rect(body, BLACK, (0, 66, 100, 14))

        rotated = pygame.transform.rotate(body, -self.angle)
        rect = rotated.get_rect(center=(self.x, self.y))
        surf.blit(rotated, rect.topleft)

        # BIG BARREL
        dx, dy = vec_from_angle(self.turret_angle)
        end_x = self.x + dx * 60
        end_y = self.y + dy * 60

        pygame.draw.line(
            surf,
            (30, 30, 30),
            (self.x, self.y),
            (end_x, end_y),
            10
        )

# ---------------- BIG BOI TANK ----------------
class BigBoiTank(EnemyTank):

    def __init__(self, x, y):
        super().__init__(x, y)

        self.color = (120, 80, 40)

        self.health = 3
        self.speed = 0.6

        self.size = 70

        self.big_shot_timer = 0
        self.big_shot_delay = 180

    def take_hit(self):
        self.health -= 1

        if self.health <= 0:
            self.alive = False

    def update(self, player, enemy_bullets, enemies):

        # normal movement/aiming AI
        EnemyTank.update(self, player, [], enemies)

        self.big_shot_timer += 1

        # ---------------- BIG BULLET ----------------
        if self.big_shot_timer > self.big_shot_delay:

            bx = self.x + math.cos(math.radians(self.turret_angle)) * 55
            by = self.y + math.sin(math.radians(self.turret_angle)) * 55

            big_bullet = Bullet(
                bx,
                by,
                self.turret_angle,
                "enemy",
                bounce=False
            )

            big_bullet.speed = 2.5
            big_bullet.radius = 16
            big_bullet.wall_piercing = True

            enemy_bullets.append(big_bullet)

            self.big_shot_timer = 0

        # BIG TRACKS
        left, right = get_tread_positions(
            self.x,
            self.y,
            self.angle,
            offset=28
        )

        GLOBAL_LEFT_TRAILS.append(left)
        GLOBAL_RIGHT_TRAILS.append(right)

    def draw(self, surf):

        # BIG BODY
        body = pygame.Surface((90, 65), pygame.SRCALPHA)
        body.fill(self.color)

        pygame.draw.rect(body, BLACK, (0, 0, 90, 12))
        pygame.draw.rect(body, BLACK, (0, 53, 90, 12))

        rotated = pygame.transform.rotate(body, -self.angle)

        rect = rotated.get_rect(center=(self.x, self.y))

        surf.blit(rotated, rect.topleft)

        # BIG BARREL
        dx, dy = vec_from_angle(self.turret_angle)

        end_x = self.x + dx * 55
        end_y = self.y + dy * 55

        pygame.draw.line(
            surf,
            (40, 20, 0),
            (self.x, self.y),
            (end_x, end_y),
            12
        )
    
# ---------------- RESET / GAME LOOP (UNCHANGED LOGIC) ----------------

def get_walls(level):
    walls = BASE_WALLS.copy()
    if level == 0:
        return BASE_WALLS.copy()
    if level == 1 or level == 2:
        walls.append(pygame.Rect(200, 180, 300, 60))
        walls.append(pygame.Rect(500, 180, 60, 600))
        walls.append(pygame.Rect(500, 780, 300, 60))

    if level == 3 or level == 4:
        walls.append(pygame.Rect(200, 600, 600, 60))
        walls.append(pygame.Rect(500, 180, 60, 600))

    if level == 5:
        # vertical bar (center)
        walls.append(pygame.Rect(WIDTH//2 - 30, 200, 60, 600))

        # horizontal bar (center)
        walls.append(pygame.Rect(200, HEIGHT//2 - 30, 600, 60))

    if level == 6 or level == 7:

        # vertical cover pillars
        walls.append(pygame.Rect(300, 0, 60, 400))
        walls.append(pygame.Rect(300, 600, 60, 400))

        walls.append(pygame.Rect(640, 0, 60, 400))
        walls.append(pygame.Rect(640, 600, 60, 400))

    if level == 8:
        # horizontal pressure lanes (NOT closed)
        walls.append(pygame.Rect(150, 250, 700, 40))
        walls.append(pygame.Rect(150, 750, 700, 40))

        # vertical partial blockers (leave gaps at top/bottom)
        walls.append(pygame.Rect(300, 0, 40, 350))
        walls.append(pygame.Rect(300, 650, 40, 350))

        walls.append(pygame.Rect(660, 0, 40, 350))
        walls.append(pygame.Rect(660, 650, 40, 350))

        # center “cover islands” (not enclosing anything)
        walls.append(pygame.Rect(450, 400, 100, 40))
        walls.append(pygame.Rect(450, 560, 100, 40))

        walls.append(pygame.Rect(180, 420, 40, 160))

    elif level == 9:

        # lane dividers (3 horizontal lanes)
        walls.append(pygame.Rect(150, 320, 700, 40))
        walls.append(pygame.Rect(150, 640, 700, 40))

        walls.append(pygame.Rect(320, 640, 40, 180))
        walls.append(pygame.Rect(640, 640, 40, 180))

    elif level == 10:

        walls.append(pygame.Rect(500, 400, 40, 400))
        walls.append(pygame.Rect(250, 400, 500, 40))



    return walls

def reset_game(level):
    global WALLS
    WALLS = get_walls(level)
    player_bullets = []
    enemy_bullets = []
    enemies = []

    player = Tank()

    player.left_trail.clear()
    player.right_trail.clear()

    for e in enemies:
        e.left_trail.clear()
        e.right_trail.clear()

    if level == 6:
        player.y = HEIGHT - 450

    if level == 9:
        player.x = WIDTH // 2
        player.y = HEIGHT - 250

    if level == 8:
        player.x = 120
        player.y = HEIGHT // 2
    

    if level == 1:
        enemies = [
            EnemyTank(800, 200),
            EnemyTank(820, 700),
            EnemyTank(700, 500),
        ]

    elif level == 2:
        enemies = [
            TripleShotTank(820, 180),
            TripleShotTank(850, 500),
            TripleShotTank(700, 300),
        ]

    elif level == 3:
        enemies = [
            EnemyTank(700, 200),
            EnemyTank(820, 600),
            TripleShotTank(400, 500),

            TripleShotTank(850, 300),
            TripleShotTank(450, 450),
        ]

    elif level == 4:
        enemies = [
            EnemyTank(700, 200),
            EnemyTank(820, 600),
            RedArmoredBurstTank(400, 500),

            TripleShotTank(850, 250),
            RedArmoredBurstTank(300, 400),
        ]
    
    elif level == 5:
        enemies = [
            RedArmoredBurstTank(400, 400),
            RedArmoredBurstTank(300, 400),
            RedArmoredBurstTank(200, 400),
            RedArmoredBurstTank(100, 400),
        ]

    elif level == 6:
        enemies = [
            SniperTank(820, 100),
            SniperTank(820, 900),

            EnemyTank(500, 100),
            EnemyTank(520, 900),

            TripleShotTank(820, 500),
        ]

    elif level == 7:
        enemies = [
            TackShooterTank(500, 500),
            TripleShotTank(800, 800),
            TripleShotTank(800, 200),
            EnemyTank(500, 800),
            EnemyTank(520, 200),
            SniperTank(700, 500),
            SniperTank(820, 900),
        ]

    elif level == 8:
        enemies = [
            TackShooterTank(500, 330),
            TackShooterTank(800, 500),
            TackShooterTank(500, 670),

            SniperTank(800, 800),
            SniperTank(800, 200),
            SniperTank(600, 800),
            SniperTank(600, 200),

            BigBoiTank(900, 500),
        ]
    
    elif level == 9:
        enemies = [
            BigBoiTank(200, 250),
            BigBoiTank(400, 250),
            BigBoiTank(600, 250),
            BigBoiTank(800, 250),

            EnemyTank(200, 400),
            EnemyTank(400, 400),


            EnemyTank(200, 600),
            EnemyTank(400, 600),

            EnemyTank(300, 600),
            EnemyTank(700, 600),

            TackShooterTank(900, 500),
            TackShooterTank(100, 500),
        ]

    elif level == 10:
        enemies = [
            BossTank(800, 150)
        ]
    
    return player, enemies, player_bullets, enemy_bullets


level = 0
tank, enemies, player_bullets, enemy_bullets = reset_game(level)
game_over = False
game_won = False

running = True
death_timer = 0

start_time = None
final_time = 0
final_score = 0

while running:
    clock.tick(60)
    screen.fill((160, 120, 80))

    # ---------------- GLOBAL TRACKS ----------------
    trail_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)

    for p in GLOBAL_LEFT_TRAILS:
        pygame.draw.circle(
            trail_surface,
            (139, 69, 19, 35),
            (int(p[0]), int(p[1])),
            3
        )

    for p in GLOBAL_RIGHT_TRAILS:
        pygame.draw.circle(
            trail_surface,
            (139, 69, 19, 35),
            (int(p[0]), int(p[1])),
            3
        )

    screen.blit(trail_surface, (0, 0))

    for w in WALLS:
        pygame.draw.rect(screen, (90, 70, 50), w)

    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and level == 0:
                level = 1
                start_time = pygame.time.get_ticks()
                tank, enemies, player_bullets, enemy_bullets = reset_game(level)
                continue

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if len(player_bullets) < 2:
                    dx, dy = vec_from_angle(tank.turret_angle)
                    bx = tank.x + dx * 35
                    by = tank.y + dy * 35

                    player_bullets.append(
                        Bullet(bx, by, tank.turret_angle, "player", bounce=True)
                    )

    keys = pygame.key.get_pressed()
    mouse_pos = pygame.mouse.get_pos()

    if tank.alive:
        tank.update(keys, mouse_pos)

    
    if tank.alive:
        tank.draw(screen)

    for e in enemies:
        e.update(tank, enemy_bullets, enemies)
        e.draw(screen)

    for b in player_bullets[:]:
        b.update()

        if not b.alive:
            player_bullets.remove(b)
            continue

        br = pygame.Rect(b.x - 4, b.y - 4, 8, 8)

        # ---- hit enemies ----
        for e in enemies[:]:
            er = get_rect(e.x, e.y)

            if br.colliderect(er):

                # if it has health (red tank)
                if hasattr(e, "health"):
                    e.take_hit()

                    if e.health <= 0:
                        enemies.remove(e)
                else:
                    enemies.remove(e)

                player_bullets.remove(b)
                break

        b.draw(screen)

    for b in enemy_bullets[:]:
        b.update()

        if not b.alive:
            enemy_bullets.remove(b)
            continue

        br = pygame.Rect(b.x - 4, b.y - 4, 8, 8)
        pr = get_rect(tank.x, tank.y)

        # ---- hit player ----
        if br.colliderect(pr) and not game_over:
            tank.alive = False
            death_timer = 120
            game_over = True
            enemy_bullets.remove(b)
            continue

        b.draw(screen)

        # ---------------- LEVEL 0 / MENU ----------------
    if level == 0:
        screen.fill((20, 20, 20))

        font = pygame.font.SysFont(None, 60)
        title = font.render("TANK GAME", True, WHITE)
        screen.blit(title, (WIDTH//2 - title.get_width()//2, 150))

        font2 = pygame.font.SysFont(None, 30)

        lines = [
            "WASD = Move tank",
            "Mouse = Aim turret",
            "Left click = Shoot",
            "",
            "Press SPACE to start"
        ]

        for i, line in enumerate(lines):
            text = font2.render(line, True, (200, 200, 200))
            screen.blit(text, (WIDTH//2 - text.get_width()//2, 300 + i * 40))

        pygame.display.flip()

        keys = pygame.key.get_pressed()

        if keys[pygame.K_SPACE]:
            level = 1
            tank, enemies, player_bullets, enemy_bullets = reset_game(level)

        continue

    
    if game_over:
        death_timer -= 1

        if death_timer <= 0:
            tank, enemies, player_bullets, enemy_bullets = reset_game(level)

            GLOBAL_LEFT_TRAILS.clear()
            GLOBAL_RIGHT_TRAILS.clear() 

            game_over = False
            death_timer = 0

    if len(enemies) == 0 and not game_over and not game_won:

        GLOBAL_LEFT_TRAILS.clear()
        GLOBAL_RIGHT_TRAILS.clear()

        # ---- CHECK WIN FIRST ----
        if level >= 10:
            game_won = True
            final_time = (pygame.time.get_ticks() - start_time) // 1000
            final_score = max(0, 100000 - (final_time * 25))

        else:
            level += 1
            tank, enemies, player_bullets, enemy_bullets = reset_game(level)
            continue

    if game_won:
        screen.fill((20, 20, 20))

        font = pygame.font.SysFont(None, 80)
        text = font.render("YOU WIN!", True, (255, 255, 255))
        screen.blit(text, (WIDTH//2 - text.get_width()//2, HEIGHT//2 - 60))

        stats_font = pygame.font.SysFont(None, 40)

        time_text = stats_font.render(
            f"Final Time: {final_time} seconds",
            True,
            (220, 220, 220)
        )

        score_text = stats_font.render(
            f"Score: {final_score}",
            True,
            (255, 220, 100)
        )

        screen.blit(
            time_text,
            (WIDTH//2 - time_text.get_width()//2, HEIGHT//2 + 20)
        )

        screen.blit(
            score_text,
            (WIDTH//2 - score_text.get_width()//2, HEIGHT//2 + 70)
        )

        font2 = pygame.font.SysFont(None, 30)
        text2 = font2.render("Press R to restart", True, (180, 180, 180))
        screen.blit(text2, (WIDTH//2 - text2.get_width()//2, HEIGHT//2 + 130))

    keys = pygame.key.get_pressed()
    if keys[pygame.K_r]:
        level = 1
        start_time = pygame.time.get_ticks()
        tank, enemies, player_bullets, enemy_bullets = reset_game(level)
        game_won = False
        game_over = False

    # ---------------- HUD ----------------
    if level != 0:

        font = pygame.font.SysFont(None, 36)

        if game_won:
            elapsed_seconds = final_time
        elif start_time is None:
            elapsed_seconds = 0
        else:
            elapsed_seconds = (pygame.time.get_ticks() - start_time) // 1000

        timer_text = font.render(f"Time: {elapsed_seconds}s", True, WHITE)
        screen.blit(timer_text, (20, 20))

        screen.blit(timer_text, (20, 20))

        screen.blit(timer_text, (20, 20))

    pygame.display.flip()

pygame.quit()